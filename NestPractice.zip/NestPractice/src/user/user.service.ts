import { Injectable } from '@nestjs/common';
import { Cat } from './schema/userSchema';
@Injectable()
export class UserService {
  private users = [
    { id: 1, name: 'vikas', age: 17, breed: 'Persian' },
    { id: 2, name: 'shubh', age: 27, breed: 'Siamese' },
    { id: 3, name: 'pashim', age: 24 },
  ];

  getAllUsers() {
    const userList = this.users;
    if (!userList || userList.length === 0) {
      return [];
    }
    return userList;
  }

  getUserById(id: number) {
    const fetchUser = this.users.find((user) => user.id === id);
    if (!fetchUser) {
      throw new Error('User not found');
    }
    return fetchUser;
  }
}
