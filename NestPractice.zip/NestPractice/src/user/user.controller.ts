import { Controller, Get, Param, NotFoundException } from '@nestjs/common';
import { UserService } from './user.service';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Get()
  getAllUsers() {
    const getUsers = this.userService.getAllUsers();
    return getUsers;
  }

  @Get(':id')
  getUserById(@Param('id') id: string) {
    try {
        const getUser = this.userService.getUserById(+id);
    } catch (error) {
      throw new NotFoundException(error.message);
    }
    
  }
}
